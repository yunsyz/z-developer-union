                     Word Search and Replace
                      Funduc Software, Inc.
                      Copyright 2000-2003
          www.funduc.com      www.searchandreplace.com
          support@funduc.com  support@searchandreplace.com

Word Search and Replace is a freeware Word macro for Microsoft
Word that can search and replace in files you specify using
Microsoft Word search and replace functioning.

IMPORTANT: Use this software at your own risk. It comes with no
warrantees of usability or safety of your data. Make backups of
all files that may be affected by your operation BEFORE you do
search and replace. DO NOT RELY on the Word 'undo' function as a
backup method -- it may not work. Use a product such as our
Directory Toolkit to zip your files or copy them to a backup path.
Please see the License Agreement for additional information. 

See Support Information concerning bug reports.

Please see Funduc Products for information on our other shareware
and freeware utilities for windows.

Requirements: 

 - To use this macro you must enable Word Macros. Some users will
   have macro functioning disabled, or at a high security setting,
   due to anti-virus measures. Consult your Microsoft Word manual
   for instructions on how to change Macro permissions. In Word
   2000, go to Tools | Macro | Security and select 'Medium' or
   'Low'. You to scan the document with your anti-virus scanner
   before running the macro for the first time.

 - If instead of the "Search and Replace in Documents" form you
   get an error message, you cannot use this script. Some versions
   of Word distributed along with Microsoft Works do not include
   the necessary VBA (Visual Basic for Applications) modules that
   are needed to perform the operation.  Upgrading to a full
   version of Word and/or Microsoft Office is the only solution.
